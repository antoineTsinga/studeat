import React from "react";

export default function Aliments() {
  return <h1>Aliments</h1>;
}
