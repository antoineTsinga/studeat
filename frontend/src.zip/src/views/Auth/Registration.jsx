import React from "react";

export default function Registration() {
  return <h1>Mon Inscription</h1>;
}
