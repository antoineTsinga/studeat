import React from "react";
import './Support.css';

export default function Support() {
  return (
    <Navbar />

  );
}
