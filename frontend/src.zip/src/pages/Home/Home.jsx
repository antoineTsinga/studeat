import React from "react";
import './Home.css';
export default function Home() {
  return <h1>TOUS ENSEMBLE POUR LUTTER CONTRE LA PRÉCARITÉ ÉTUDIANTE</h1>;
}
